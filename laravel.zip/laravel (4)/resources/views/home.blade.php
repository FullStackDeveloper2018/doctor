@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            <div class="card-header">{{ __('Input Patient Info') }}</div>
                <form method = "get" action = "{{url('/generate-pdf')}}">
                    <div class="card-body" style ="min-height: 368px;">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div class="row">
                        <div class="col-md-5">
                            <label for="firstname">{{ __('Patient Email') }}</label>
                        </div>
                        <div class="col-md-6">
                            <input id="email" name = "email" required placeholder = "patient email" type="email" class="form-control" autofocus>
                        </div>
                    </div>
                    <div class="row" style = "margin-top: 20px">
                        <div class="col-md-5">
                            <label for="lastname">{{ __('PassPort') }}</label>
                        </div>
                        <div class="col-md-6">
                            <input id = "passport" type="text" name = "passport" required class="form-control" placeholder = "passport">
                        </div>
                    </div>
                
                    <div class="row" style = "margin-top: 20px">
                        <div class="col-md-8">
                        </div>
                        <div class="col-md-3">
                            <button type="submit" value = "submit" class="btn btn-success">Create Account</button>
                        </div>
                        <!-- <div class="col-md-2">
                        </div> -->
                    </div>
                
                </form>

            </div>
        </div>
    </div>
</div>
@endsection
