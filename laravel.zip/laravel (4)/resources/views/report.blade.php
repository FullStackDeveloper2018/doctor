<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{('assets/css/custom.css')}}">
    <title>One Page</title>
    <style>
        #example1 {
            background: url({{asset('assets/images/background.png')}});
            background-repeat: no-repeat;
            background-size: 60% ;
            background-position: center;

        }
    </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<section class="d-flex">
    <div class="box_title container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-8">
                <form enctype="multipart/form-data" action="{{url('file-upload')}}" method="POST">
                    @csrf
                    <input type="hidden" name="reportname" value="{{$data['reportname']}}">
                    <div class = "row" style="margin-top: 20px">
                        <div class = "col-md-3">
                        </div>
                        <div class = "col-md-5" style="padding-left: 20px">
                            <input type="file" class="btn btn-success" id="file" name="file_url" value="Select File" required>
                        </div>
                        <div class="col-md-3" style="padding-left: 20px">
                            <input type="submit" class="btn btn-success" value="Upload">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div style="width:1200px;" id="peruser_tab_view_table">
            <div class="first_part row">
                <div class="col-md-4">
                    <div class="border_line">
                    <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_1">
                        تبر الزوراء المركزي<br>
                        للتحليلات المرضية
                    </P>
                    <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_1">
                        المختبر مجاز من قبل وزارة الصحة<br>
                        السعودية
                    </P>
                    </div>
                    <P class="content_2">
                        Health Certificate<br>
                        2019 Novel Coronavirus test
                    </P>

                </div>
                <div class="medical_img col-md-4">
                    <img class="image_box img-fluid" src="{{asset('assets/images/medical.jpg')}}">
                </div>
                <div class="title_1 col-md-4">
                    <p  class="content_1" >
                        <span style=" font-family: DejaVu Sans, sans-serif;color: #000000;">وزارة الصحة / البيئة<br>
                        دائرة العيادات الطبية الشعبية<br></span>
                        Republic of  Saudi<br>
                        Ministry of Health/Environment<br>
                        Directorate of Popular Medical Clinics<br>

                    </p>
                    <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_2">
                        شهادة صحية<br>
                        فحص فايروس كورونا المستجد
                    </P>
                </div>
            </div>
            <div  class="row">
                <div class="col-md-6">
                    <P class="content_3">
                        This certificate is upon personal request , not under any responsibility
                    </P>
                </div>
                <div class="col-md-6">
                    <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;text-align: center;" class="content_3">
                        منحت هذه الشهادة بناء على رغبة الشخص دون اي مسؤولية على الجهة المانحة
                    </P>
                </div>
            </div>
            <section id="example1">
            <div class="row">
                <div class="col-md-12">
                    <div class="part_1">
                        <div class="row">
                        <div class="col-md-6">
                                <P class="content_4" >
                                    Full Name:- {{$data['fullname']}}<br>
                                    Gender:- {{$data['gender']}}<br>
                                    Age  :- {{$data['age']}} Y
                                </P>
                            </div>
                            <div class="col-md-6">
                                <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_5" >
                                 الأسم الكامل :- {{$data['fullname-arb']}} <br>
                                {{$data['gender-arb']}}-: الجنس<br>
                                {{$data['age']}} :- العمر<br>
                                </P>
                            </div>
                        </div>

                        <hr class="across_line">
                        <div class="row">
                            <div class="col-md-6">
                                <P class="content_4" >
                                    Registration No. {{$data['registration']}}
                                </P>
                            </div>
                            <div class="col-md-6">
                                <P class="content_5" >
                                {{$data['registration-arb']}} .رقم التسلسل
                                </P>
                            </div>
                        </div>
                        <hr class="across_line">
                        <div class="row">
                            <div class="col-md-6">
                                <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_4" >
                                    Passport /ID No.{{$data['Passport']}}
                                </P>
                            </div>
                            <div class="col-md-6">
                                <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_5" >
                                {{$data['Passport-arb']}} رقم الجواز/ البطاقة التعريفية
                                </P>
                            </div>
                        </div>
                        <hr class="across_line">
                        <div class="row">
                            <div class="col-md-6">
                                <P class="content_4" >
                                    Date of report {{ date('Y/m/d') }}
                                </P>
                            </div>
                            <div class="col-md-6">
                                <P style=" font-family: DejaVu Sans, sans-serif;color: #000000;padding-right:10px;" class="content_5" >
                                    {{ date('Y/m/d') }}&nbsp تاريخ الفحص
                                </P>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <p class="content_6">
                        NEGATIVE RESULT DOSE NOT EXCLUDE COVID-19 ANT ITS<br>
                        CONSEQUENCES WHILE POSITIVE RESULT MEANS ACTIVE<br>
                        INFECTION WITH SARS-CoV-19. MEDICAL EXAMINATION<br>
                        AND PATIENT HISTORY SHOULD BE CORRELATED<br>
                    </p>
                </div>
                <div class="col-md-6">
                    <p style=" font-family: 'Droid Arabic Kufi'; color: #000000;" class="content_7">
                        النتيجة السالبة لا تنفي عدم الاصابه بمرض كوقيد 19 او عواقبه بينما النتيجة<br>
                        الموجبة تعني الاصابه الفعالة بالمرض والإصابة بفايروس كورونا 19 المستجد<br>
                        يجب ربط الحالة  الطبية والتاريخ المرضي مع فحص المسحة او الدم
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <p class="content_6"><span style="color: #ff0000"> SWAB</span> test (2019-nCoV)</p>
                </div>
                <div class="col-md-4">
                    <p class="content_8">(<span style="color: #ff0000">E-gene, N-gene, RdRp</span>)</p>
                </div>
                <div class="col-md-4">
                    <p class="content_7" style=" font-family: DejaVu Sans, sans-serif;color: #000000;">(2019-nCoV) فحص  <span style="color: #ff0000">  مسحة</span></p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <span class="content_6">WE CERTIFY THAT A <span style="color: #ff0000"> SWAB</span> from THIS PERSON is<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;tested for COVID-19 BY (real time-PCR)<br>
                        &nbsp;&nbsp;&nbsp;&nbsp;TEST INTERPRETATION RESULT
                    </span>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4">
                    <p style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_7"> نؤكد ان  <span style="color: #ff0000"> &nbsp مسحة</span>&nbsp الشخص اعلاه قد تم فحصها لمرض      </p>
                    <p style=" font-family: DejaVu Sans, sans-serif;color: #000000;" class="content_7">
                        ( real time-PCR ) بطريقة COVID-19<br>
                        نتيجة الفحص
                    </p>


                </div>
            </div>
            <div class="row">
                <div class="col-md-4"></div>
                <div  class="border_line_1 col-md-4">
                    <p class="content_10">
                        {{$data['result']}} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {{$data['result-arb']}}
                    </p>
                </div>
                <div class="col-md-4"></div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <p class="border_line_2 content_11">
                        NO 2019 Novel Coronavirus (2019-nCov) RNA was detected in the specimen ,and
                        The concentration was lower than the sensitivity of the kit.
                    </p>
                </div>
            </div>
            </section>
            <div class="second_part row">
                <div class="col-md-7">
                    <p class="content_12">
                        Use the mobile application to Scan the QR code
                    </p>
                    <p class="content_13">
                        TRAVEL DATE CHANGES IS NOT OUR RESPONSIBILITY
                    </p>
                </div>
                <div class="col-md-5">
                    <p style=" font-family: DejaVu Sans, sans-serif;" class="content_12">
                        استخدم تطبيق الموبايل لمسح البار كود للتأكد من صحة التقرير
                    </p>
                    <p style=" font-family: DejaVu Sans, sans-serif;" class="content_13">
                        التغييرات في مواعيد السفر ليست مسؤوليتنا
                    </p>
                </div>
            </div>
            <div class="second_part row">
                <div class="col-md-1"></div>
                <div class="box_position col-md-3">
                    <div class="box"></div>
                </div>
                <div class="image_box_1 col-md-4">
                    <img class="img-fluid" src="{{asset('images/'.$qrcode.'.png')}}">
                </div>
                <div style="padding-left:20px;" class="col-md-3">
                    <div class="box">
                    </div>
                </div>
                <div class="col-md-1"></div>
            </div>
            <div class="third_part row">
                <div class="col-md-3"></div>
                <div class="col-md-2">
                    <p class="content_14">Director</p>
                </div>
                <div class="col-md-2">
                    <p class="content_14">Authorization</p>
                </div>
                <div class="col-md-2">
                    <p class="content_14">Examination</p>
                </div>
                <div class="col-md-3"></div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <p style=" font-family: DejaVu Sans, sans-serif;" class="content_15">للاستفسار: 07808889899 -يجب استلم النسخة الورقية لغرض السف</p>
                    <p style=" font-family: DejaVu Sans, sans-serif;" class="content_16">خدمه 24 ساعه وعلى مدار الاسبوع ويتم تسليم النتيجة بما لا يزيد عن 24 ساعه مع مراعاة الحالات الطارئة</p>
                </div>
            </div>
        </div>
    </div>

</section>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/js/jquery.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
<script src="{{ asset('assets/js/analytic.js') }}"></script>
<script src="{{ asset('assets/js/analytics_e.js') }}"></script>
<script src="{{asset('assets/js/custom.js')}}"></script>
<div class="pdf-generating" style="display: none">
    <p>Please wait some seconds while generating a pdf . . .</p>
</div>
<script>
    generatePDF(this, 'peruser_tab_view_table');
</script>
</body>
</html>