@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style = "background-color: rgba(1,140,149,.1);">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="post" action="{{ route('create.identity') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="identifier" class="col-md-4 col-form-label text-md-right">{{ __('Patient Identifier') }}</label>

                            <div class="col-md-6">
                                <input id="identifier" type="text" class="form-control" name="identifier" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="device" class="col-md-4 col-form-label text-md-right">{{ __('Manufacture of device') }}</label>

                            <div class="col-md-6">
                                <input id="device" type="text" class="form-control" name="device" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="numberofdevice" class="col-md-4 col-form-label text-md-right">{{ __('Number of Device') }}</label>

                            <div class="col-md-6">
                                <input id="numberofdevice" type="text" class="form-control" name="numberofdevice" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="manufacturerofreagent" class="col-md-4 col-form-label text-md-right">{{ __('Manufacturer Of Reagent') }}</label>

                            <div class="col-md-6">
                                <input id="manufacturerofreagent" type="text" class="form-control" name="manufacturerofreagent" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="calibration_date" class="col-md-4 col-form-label text-md-right">{{ __('Calibration Date') }}</label>

                            <div class="col-md-6">
                                <input id="calibration_date" type="date" class="form-control" name="calibration_date" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="technician_or_physician_name" class="col-md-4 col-form-label text-md-right">{{ __('technician_or_physician_name') }}</label>

                            <div class="col-md-6">
                                <input id="technician_or_physician_name" type="text" class="form-control" name="technician_or_physician_name" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="number_of_cycles" class="col-md-4 col-form-label text-md-right">{{ __('number_of_cycles') }}</label>

                            <div class="col-md-6">
                                <input id="number_of_cycles" type="text" class="form-control" name="number_of_cycles" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="test_result" class="col-md-4 col-form-label text-md-right">{{ __('test_result') }}</label>

                            <div class="col-md-6">
                                <input id="test_result" type="text" class="form-control" name="test_result" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="test_name" class="col-md-4 col-form-label text-md-right">{{ __('test_name') }}</label>

                            <div class="col-md-6">
                                <input id="test_name" type="text" class="form-control" name="test_name" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="test_subtype_id" class="col-md-4 col-form-label text-md-right">{{ __('test_subtype_id') }}</label>

                            <div class="col-md-6">
                                <input id="test_subtype_id" type="text" class="form-control" name="test_subtype_id" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="custom_patient_id" class="col-md-4 col-form-label text-md-right">{{ __('custom_patient_id') }}</label>

                            <div class="col-md-6">
                                <input id="custom_patient_id" type="text" class="form-control" name="custom_patient_id" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="test_type_id" class="col-md-4 col-form-label text-md-right">{{ __('test_type_id') }}</label>

                            <div class="col-md-6">
                                <input id="test_type_id" type="text" class="form-control" name="test_type_id" required >

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="test_date" class="col-md-4 col-form-label text-md-right">{{ __('test_date') }}</label>

                            <div class="col-md-6">
                                <input id="test_date" type="date" class="form-control" name="test_date" required >

                            </div>
                        </div>
                        
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 text-right">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Get data') }}
                                </button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>
@endsection
