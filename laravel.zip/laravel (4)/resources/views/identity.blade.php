@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style = "background-color: rgba(1,140,149,.1);">{{ __('Register') }}</div>

                <div class="card-body">
                    @if(isset($response['data']))
                        <div class = "row">
                            <div class = "col-md-2">
                            Address: 
                           </div>
                           <div class = "col-md-10">
                                <input type="text" name='dob1' style = "width: 100%" disabled value=" {{ $response['data']['attributes']['address'] }} ">
                           </div>
                        </div>
                        <div class = "row">
                            <div class = "col-md-2">
                            Email: 
                           </div>
                           <div class = "col-md-10">
                                <input type="text" name='dob2' style = "width: 100%" disabled value=" {{ $response['data']['attributes']['email'] }} ">
                           </div>
                        </div>
                        <div class = "row">
                            <div class = "col-md-2">
                            passport: 
                           </div>
                           <div class = "col-md-10">
                                <input type="text" name='dob3' style = "width: 100%" disabled value=" {{ $response['data']['attributes']['passport'] }} ">
                           </div>
                        </div>
                        <div class = "row">
                            <div class = "col-md-2">
                            role: 
                           </div>
                           <div class = "col-md-10">
                                <input type="text" name='dob4' style = "width: 100%" disabled value=" {{ $response['data']['attributes']['role'] }} ">
                           </div>
                        </div>
                        <div class = "row">
                            <div class = "col-md-2">
                            status: 
                           </div>
                           <div class = "col-md-10">
                                <input type="text" name='dob5' style = "width: 100%" disabled value=" {{ $response['data']['attributes']['status'] }} ">
                           </div>
                        </div>
                    @else
                        <div class = "row">
                            <div class = "col-md-12 text-center">
                                {{$error}}
                            </div>
                        </div>
                    @endif
                </div>
            </div>
            
        </div>
    </div>
</div>
@endsection
