<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{('assets/css/custom.css')}}">
    <title>One Page</title>
    <style>
        #example1 {
            background: url({{asset('assets/images/background.png')}});
            background-repeat: no-repeat;
            background-size: 60% ;
            background-position: center;

        }
    </style>
</head>
<body width = "564px" height = "1000px">
<section class="d-flex">
    <div class="box_title container">
        <div class="row">
            <div class="col-md-4">
                <div class="border_line">
                <P class="content_1">
                    تبر الزوراء المركزي<br>
                    للتحليلات المرضية
                </P>
                <P class="content_1">
                    المختبر مجاز من قبل وزارة الصحة<br>
                    السعودية
                </P>
                </div>
                <P class="content_2">
                    Health Certificate<br>
                    2019 Novel Coronavirus test
                </P>

            </div>
            <div class="medical_img col-md-3">
                <img class="image_box img-fluid" src="{{asset('assets/images/medical.jpg')}}">
            </div>
            <div class="title_1 col-md-5">
                <p class="content_1" >
                    وزارة الصحة / البيئة<br>
                    دائرة العيادات الطبية الشعبية<br>
                    Republic of  Saudi<br>
                    Ministry of Health/Environment<br>
                    Directorate of Popular Medical Clinics<br>

                </p>
                <P class="content_2">
                    شهادة صحية<br>
                    فحص فايروس كورونا المستجد
                </P>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <P class="content_3">
                    This certificate is upon personal request , not under any responsibility
                </P>
            </div>
            <div class="col-md-6">
                <P class="content_3">
                    منحت هذه الشهادة بناء على رغبة الشخص دون اي مسؤولية على الجهة المانحة
                </P>
            </div>
        </div>
        <section id="example1">
        <div class="row">
            <div class="col-md-12">
                <div class="part_1">
                    <div class="row">
                        <div class="col-md-6">
                            <P class="content_4" >
                                Full Name:- {{$data['fullname']}}<br>
                                Gender:- {{$data['gender']}}<br>
                                Age  :- {{$data['age']}} Y
                            </P>
                        </div>
                        <div class="col-md-6">
                            <P class="content_5" >
                            {{$data['fullname-arb']}}<br>
                            {{$data['gender-arb']}}<br>
                            {{$data['age']}}:- العمر<br>
                            </P>
                        </div>
                    </div>

                    <hr class="across_line">
                    <div class="row">
                        <div class="col-md-6">
                            <P class="content_4" >
                                Registration No. {{$data['registration']}}
                            </P>
                        </div>
                        <div class="col-md-6">
                            <P class="content_5" >
                            {{$data['registration-arb']}}رقم التسلسل 
                            </P>
                        </div>
                    </div>
                    <hr class="across_line">
                    <div class="row">
                        <div class="col-md-6">
                            <P class="content_4" >
                                Passport /ID No.{{$data['Passport']}}
                            </P>
                        </div>
                        <div class="col-md-6">
                            <P class="content_5" >
                            {{$data['Passport-arb']}} رقم الجواز/ البطاقة التعريفية  
                            </P>
                        </div>
                    </div>
                    <hr class="across_line">
                    <div class="row">
                        <div class="col-md-6">
                            <P class="content_4" >
                                Date of report {{ date('Y/m/d') }}
                            </P>
                        </div>
                        <div class="col-md-6">
                            <P class="content_5" >
                                {{ date('Y/m/d') }}تاريخ الفحص 
                            </P>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <p class="content_6">
                    NEGATIVE RESULT DOSE NOT EXCLUDE COVID-19 ANT ITS<br>
                    CONSEQUENCES WHILE POSITIVE RESULT MEANS ACTIVE<br>
                    INFECTION WITH SARS-CoV-19. MEDICAL EXAMINATION<br>
                    AND PATIENT HISTORY SHOULD BE CORRELATED<br>
                </p>
            </div>
            <div class="col-md-6">
                <p class="content_7">
                    النتيجة السالبة لا تنفي عدم الاصابه بمرض كوقيد 19 او عواقبه بينما النتيجة<br>
                    الموجبة تعني الاصابه الفعالة بالمرض والإصابة بفايروس كورونا 19 المستجد<br>
                    يجب ربط الحالة  الطبية والتاريخ المرضي مع فحص المسحة او الدم
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <p class="content_6"><span style="color: #ff0000"> SWAB</span> test (2019-nCoV)</p>
            </div>
            <div class="col-md-4">
                <p class="content_8">(<span style="color: #ff0000">E-gene, N-gene, RdRp</span>)</p>
            </div>
            <div class="col-md-4">
                <p class="content_7">(2019-nCoV) <span style="color: #ff0000">  مسحة</span>فحص </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <span class="content_6">WE CERTIFY THAT A <span style="color: #ff0000"> SWAB</span> from THIS PERSON is<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;tested for COVID-19 BY (real time-PCR)<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;TEST INTERPRETATION RESULT
                </span>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <p class="content_7">الشخص اعلاه قد تم فحصها لمرض      <span style="color: #ff0000">  مسحة</span>نؤكد ان <br>                                                                                           ( real time-PCR ) بطريقة COVID-19<br>
                 نتيجة الفحص
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4"></div>
            <div  class="border_line_1 col-md-4">
                <p class="content_10">
                    Negative &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; غير مصاب
                </p>
            </div>
            <div class="col-md-4"></div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p class="border_line_2 content_11">
                    NO 2019 Novel Coronavirus (2019-nCov) RNA was detected in the specimen ,and
                    The concentration was lower than the sensitivity of the kit.
                </p>
            </div>
        </div>
        </section>
        <div class="row">
            <div class="col-md-7">
                <p class="content_12">
                    Use the mobile application to Scan the QR code
                </p>
                <p class="content_13">
                    TRAVEL DATE CHANGES IS NOT OUR RESPONSIBILITY
                </p>
            </div>
            <div class="col-md-5">
                <p class="content_12">
                    استخدم تطبيق الموبايل لمسح البار كود للتأكد من صحة التقرير
                </p>
                <p class="content_13">
                    التغييرات في مواعيد السفر ليست مسؤوليتنا
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-1"></div>
            <div class="box_position col-md-3">
                <div class="box"></div>
            </div>
            <div class="image_box_1 col-md-4">
                <img class="img-fluid" src="{{'images/'.$data['qrcode'].'.png'}}">
            </div>
            <div class="col-md-3">
                <div class="box">
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-2">
                <p class="content_14">Director</p>
            </div>
            <div class="col-md-2">
                <p class="content_14">Authorization</p>
            </div>
            <div class="col-md-2">
                <p class="content_14">Examination</p>
            </div>
            <div class="col-md-3"></div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p class="content_15">للاستفسار: 07808889899 -يجب استلم النسخة الورقية لغرض السف</p>
                <p class="content_16">خدمه 24 ساعه وعلى مدار الاسبوع ويتم تسليم النتيجة بما لا يزيد عن 24 ساعه مع مراعاة الحالات الطارئة</p>
            </div>
        </div>
    </div>

</section>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{('assets/js/jquery.min.js')}}"></script>
<script src="{{('assets/js/custom.js')}}"></script>
</body>
</html>