<?php
  
namespace App\Http\Controllers;
use QrCode;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use PDF;
use App\Models\Report;
  
class PDFController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function generatePDF(Request $request)
    {
        dd($request);
        QrCode::size(500)

            ->format('png')

            ->generate('https://nursinghomeprivatehospital.com/lab/cov19resultvalidation/UrlReport//NHS72837.pdf', public_path('images/qrcode.png'));

        $data = [
            'title' => 'Welcome to ItSolutionStuff.com',
            'date' => date('m/d/Y'),
            
        ];
        $pdf = PDF::loadView('pdfmodel', $data);
        return $pdf->download('report.pdf');

        return view('home');
    }

    public function create(Request $request)
    {
        $filename = "report".mt_rand(1000000, 9999999);
        $filePDF = $filename.".pdf";
        $registration = mt_rand(1000000, 9999999);
        $report = new Report;
        $report->fullname = $request['fullname'];
        $report->fullnameArb = $request['fullname-arb'];
        $report->gender = $request['gender'];
        $report->genderArb = $request['gender-arb'];
        $report->age = $request['age'];
        $report->ageArb = $request['age-arb'];
        $report->registration = $request['result'];
        $report->registrationArb = $request['result-arb'];
        $report->Passport = $request['Passport'];
        $report->PassportArb = $request['Passport-arb'];
        $report->qrcodeimagename = $filename.".png";
        $report->reportname = $filename.".pdf";
        $report->save();
        QrCode::size(500)

            ->format('png')

            ->generate('localhost:800/public/reports/'.$filePDF, public_path('images/'.$filename.'.png'));
        $data = [
            'fullname' => $request['fullname'],
            'gender' => $request['gender'],
            'age' => $request['age'],
            'registration' => $report->id,
            'Passport' => $request['Passport'],
            'fullname-arb' => $request['fullname-arb'],
            'gender-arb' => $request['gender-arb'],
            'age-arb' => $request['age-arb'],
            'registration-arb' => $report->id,
            'Passport-arb' => $request['Passport-arb'],
            'qrcode' => $filename,
            'result' => $request['result'],
            'result-arb' => $request['result-arb'],
            'reportname' =>$filename,
        ];

        // create new report colum
        
        // creat new report pdf 

//        $pdf = PDF::loadView('pdfmodel', ['data' => $data]);
//
//        $file = public_path()."/reports/".$filePDF;
//        $pdf->save($file);
        return view('report')->with('data', $data)->with('qrcode', $filename);
    }

    public function uploadFile(Request $request) {

        try {
            $request->validate([
                'reportname' => 'required'
            ]);

            if(file_exists($request->file_url)) {

                $file = $request->file_url;

                $file_ext = $file->getClientOriginalExtension();

                if($file_ext != 'pdf' && $file_ext != 'PDF') {
                    return redirect('/')->with('error', $file_ext. ' type of file is not allowed.');
                }

//            if($file->getSize() < 8) {
//                return redirect()->route('document.create')->with('failure', 'This file is more than 8M.');
//            }

                $destinationPath = 'reports';
                $file_realPath = $destinationPath . '/' . $request->reportname . '.' . $file_ext;
                $file->move($destinationPath,$request->reportname . '.' . $file_ext);

                return redirect('/')->with('success', 'Success');
            }
            else {
                return redirect('/')->with('error', 'Not select File');
            }

        } catch (\Exception $e) {
            return redirect('/')->with('error', $e->getMessage());
        }


    }

}



