<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PatientController extends Controller
{
    public function create(Request $request)
    {
        // dd(json_encode($request['email']));
        $email = $request['email'];
        $passport = $request['passport'];
        
        
        $request = json_encode('{'.
            '"data": {'.
                '"id": "GDWJMVJOGXONUE7EBLDNAQ4ZI5EIZ4DUNHGOA5UODYC2H6UTVMBPD67J",'.
                '"type": "identity",'.
                '"attributes": {'.
                    '"email": "'.$email.'",'.
                    '"passport": "'.$email.'"'.
                '}'.
            '}'.
        '}');
       
       
        $request = '{'.
            '"data": {'.
                '"id": "GDWJMVJOGXONUE7EBLDNAQ4ZI5EIZ4DUNHGOA5UODYC2H6UTVMBPD67J",'.
                '"type": "identity",'.
                '"attributes": {'.
                    '"email": "'.$email.'",'.
                    '"passport": "'.$passport.'"'.
                '}'.
            '}'.
        '}';
        $response = Http::timeout(5)->withBody($request, 'application/json')->post('http://199.192.23.4:5555/identities')->json();
        
        if(isset($response['data'])){
            return view('identity')->with('response', $response);
        }
        else{
            return view('identity')->with('error', 'This patient dont have identity.');
        }
        
        

    }
    public function getIdentity()
    {
        return view('getIdentity');
        
    }

    public function viewIdentity(Request $request)
    {
        
        $identifier = $request['identifier'];
        $request = '{}';
        $response = Http::timeout(5)->withBody($request, 'application/json')->get('http://199.192.23.4:5555/integrations/test-results/'.$identifier)->json();
        dd($response);
    }
    public function createtest()
    {
        return view('createtest');
    }
    
    public function inserttest(Request $request)
    {
      $identifier = $request['identifier'];
      $device = $request['device'];
      $numberofdevice = $request['numberofdevice'];
      $manufacturerofreagent = $request['manufacturerofreagent'];
      $calibration_date = $request['calibration_date'];
      $technician_or_physician_name = $request['technician_or_physician_name'];
      $number_of_cycles = $request['number_of_cycles'];
      $test_result = $request['test_result'];
      $test_name = $request['test_name'];
      $test_subtype_id = $request['test_subtype_id'];
      $custom_patient_id = $request['custom_patient_id'];
      $test_type_id = $request['test_type_id'];
      $test_date = $request['test_date'];
      
      $request = '{'.
        '"data": {'.
          '"participant": "'.$identifier.'",
          "manufacturer_of_prc_device": "'.$device.'",
          "serial_number_of_device": "'.$numberofdevice.'",
          "manufacturer_of_reagent": "'.$manufacturerofreagent.'",
          "calibration_date": "'.$calibration_date.'",
          "technician_or_physician_name": "'.$technician_or_physician_name.'",
          "number_of_cycles": "'.$number_of_cycles.'",
          "test_result": "'.$test_result.'",
            "test_name": "'.$test_name.'",
          "test_subtype_id": "'.$test_subtype_id.'",
          "custom_patient_id": "'.$custom_patient_id.'",
          "test_type_id": "'.$test_type_id.'",
          "test_date": "'.$test_date.'",
          "documents": {'.
            '"patient_photo": {'.
              '"content": "base64",
              "name": "'.public_path('images/qrcode.png').'",
              "mime_type": "image/png"'.
            '}'.',
            "additional_files": {'.
              '"content": "base64",
              "name": "'.public_path('report.pdf').'",
              "mime_type": "application/pdf"'.
            '}'.',
            "pcr_raw_machine_data": {'.
              '"content": "",
              "name": "",
              "mime_type": ""'.
            '}'.
          '}'.'
          "comments": "string"'.
        '}'.
      '}';
    $response = Http::timeout(5)->withBody($request, 'application/json')->post('http://199.192.23.4:5555/integrations/hgate/tests')->json();
    
    dd($response);

    }
}
