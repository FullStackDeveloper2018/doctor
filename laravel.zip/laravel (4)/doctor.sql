/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.17-MariaDB : Database - doctor
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2021_03_15_083327_create_patients_table',1),
(5,'2021_03_17_095258_create_reports_table',2);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `patients` */

DROP TABLE IF EXISTS `patients`;

CREATE TABLE `patients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `patients` */

/*Table structure for table `reports` */

DROP TABLE IF EXISTS `reports`;

CREATE TABLE `reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullnameArb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `genderArb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ageArb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationArb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Passport` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PassportArb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qrcodeimagename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `reports` */

insert  into `reports`(`id`,`fullname`,`fullnameArb`,`gender`,`genderArb`,`age`,`ageArb`,`registration`,`registrationArb`,`Passport`,`PassportArb`,`qrcodeimagename`,`reportname`,`created_at`,`updated_at`) values 
(1,'alexeychaychenko','alexeychaychenko','male','الذكر','23','23','2342KE','2342KE','2342KEEFW3','2342KEEFW3','report5169866.png','report5169866.pdf','2021-03-17 10:06:25','2021-03-17 10:06:25'),
(2,'sdf','sssdfsdf','sdf','sdf','sdf','dfsdf','GgnNNvE','GgnNNvE','sdf','sdf','report1590072.png','report1590072.pdf','2021-03-17 11:09:49','2021-03-17 11:09:49'),
(3,'alexey','احمد علي','male','الذكر','34','34','taokl3s','taokl3s','KDEPDD34D','KDEPDD34D','report7231896.png','report7231896.pdf','2021-03-17 11:13:28','2021-03-17 11:13:28'),
(4,'alexey','احمد علي','male','الذكر','34','34','v9bwnmx','v9bwnmx','KDEPDD34D','KDEPDD34D','report4062520.png','report4062520.pdf','2021-03-17 11:15:34','2021-03-17 11:15:34'),
(5,'alexey','احمد علي','male','الذكر','34','34','hZe72f6','hZe72f6','KDEPDD34D','KDEPDD34D','report9114162.png','report9114162.pdf','2021-03-17 11:16:00','2021-03-17 11:16:00'),
(6,'alexey','احمد علي','male','الذكر','34','34','VxOi9F8','VxOi9F8','KDEPDD34D','KDEPDD34D','report1660556.png','report1660556.pdf','2021-03-17 11:18:30','2021-03-17 11:18:30'),
(7,'alexey','احمد علي','male','الذكر','34','34','5340355','5340355','KDEPDD34D','KDEPDD34D','report9694507.png','report9694507.pdf','2021-03-17 11:19:36','2021-03-17 11:19:36'),
(8,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report7437373.png','report7437373.pdf','2021-03-17 11:23:18','2021-03-17 11:23:18'),
(9,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report2577920.png','report2577920.pdf','2021-03-17 11:23:49','2021-03-17 11:23:49'),
(10,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report6635960.png','report6635960.pdf','2021-03-17 11:26:44','2021-03-17 11:26:44'),
(11,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report8311788.png','report8311788.pdf','2021-03-17 11:27:18','2021-03-17 11:27:18'),
(12,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report5473980.png','report5473980.pdf','2021-03-17 11:27:37','2021-03-17 11:27:37'),
(13,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report4658917.png','report4658917.pdf','2021-03-17 11:30:59','2021-03-17 11:30:59'),
(14,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report7173182.png','report7173182.pdf','2021-03-17 11:32:24','2021-03-17 11:32:24'),
(15,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report4225967.png','report4225967.pdf','2021-03-17 11:33:28','2021-03-17 11:33:28'),
(16,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report8670219.png','report8670219.pdf','2021-03-17 11:34:50','2021-03-17 11:34:50'),
(17,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report9918676.png','report9918676.pdf','2021-03-17 11:35:21','2021-03-17 11:35:21'),
(18,'alexey','احمد علي','male','الذكر','34','34','','','KDEPDD34D','KDEPDD34D','report3146379.png','report3146379.pdf','2021-03-17 12:10:20','2021-03-17 12:10:20'),
(19,'sdf','احمد علي','sdf','الذكر','sdf','جواز سفر','Positive','إيجابي','KDEPDD34D','KDEPDD34D','report7817122.png','report7817122.pdf','2021-03-17 12:23:40','2021-03-17 12:23:40'),
(20,'alexeychaychenko','احمد علي','male','الذكر','34','34','Invalid','غير صالح','KDEPDD34D','KDEPDD34D','report3021791.png','report3021791.pdf','2021-03-17 12:25:00','2021-03-17 12:25:00'),
(21,'alexeychaychenko','احمد علي','male','الذكر','34','34','Positive','إيجابي','KDEPDD34D','KDEPDD34D','report1372104.png','report1372104.pdf','2021-03-17 12:28:41','2021-03-17 12:28:41');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
